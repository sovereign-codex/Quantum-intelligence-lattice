import os, asyncio, argparse
from fastapi import FastAPI
from app.orchestrator import Orchestrator

CSV_PATH = os.environ.get("QIL_CSV", "data/QIL_365_VOT_Metrics_Plan.csv")

app = FastAPI(title="QIL – VOT Orchestrator")

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse

paused_days: set[int] = set()

@app.get("/admin", response_class=HTMLResponse)
async def admin_page():
    html = """<!doctype html>
<html><head><meta charset=\"utf-8\"><title>QIL Admin</title></head>
<body style=\"font-family:system-ui,-apple-system,Segoe UI,Roboto\">
<h1>QIL Admin</h1>
<div style=\"display:grid;gap:12px;max-width:720px\">
  <section>
    <h3>Pause / Resume</h3>
    <form onsubmit=\"return send(event, '/admin/pause')\">
      <label>Days (comma-separated): <input name=\"days\" placeholder=\"1,2,3\"/></label>
      <button type=\"submit\">Pause</button>
    </form>
    <form onsubmit=\"return send(event, '/admin/resume')\">
      <label>Days (comma-separated): <input name=\"days\" placeholder=\"1,2,3\"/></label>
      <button type=\"submit\">Resume</button>
    </form>
  </section>
  <section>
    <h3>Retry (force schedule)</h3>
    <form onsubmit=\"return send(event, '/admin/retry')\">
      <label>Days (comma-separated): <input name=\"days\" placeholder=\"4,5\"/></label>
      <button type=\"submit\">Retry</button>
    </form>
  </section>
  <section>
    <h3>Set Concurrency</h3>
    <form onsubmit=\"return send(event, '/admin/concurrency')\">
      <label>N: <input name=\"n\" value=\"32\"/></label>
      <button type=\"submit\">Apply</button>
    </form>
  </section>
  <section>
    <h3>Status</h3>
    <button onclick=\"refreshStatus()\">Refresh</button>
    <pre id=\"status\"></pre>
  </section>
</div>
<script>
async function send(ev, path){
  ev.preventDefault();
  const fd = new FormData(ev.target);
  const payload = {};
  for (const [k,v] of fd.entries()){
    if(k==='days'){ payload['days'] = v.split(',').map(s=>parseInt(s.trim())).filter(n=>!isNaN(n)); }
    if(k==='n'){ payload['n'] = parseInt(v); }
  }
  const res = await fetch(path, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
  const js = await res.json();
  alert(JSON.stringify(js, null, 2));
  return false;
}
async function refreshStatus(){
  const res = await fetch('/status');
  const js = await res.json();
  document.getElementById('status').textContent = JSON.stringify(js, null, 2);
}
refreshStatus();
</script>
</body></html>"""
    return HTMLResponse(html)

@app.post("/admin/pause")
async def admin_pause(payload: dict):
    days = set(payload.get("days") or [])
    paused_days.update(days)
    return {"paused_added": sorted(list(days)), "paused_total": len(paused_days)}

@app.post("/admin/resume")
async def admin_resume(payload: dict):
    days = set(payload.get("days") or [])
    for d in list(days):
        paused_days.discard(d)
    return {"resumed": sorted(list(days)), "paused_total": len(paused_days)}

@app.post("/admin/retry")
async def admin_retry(payload: dict):
    days = payload.get("days") or []
    if orch is None:
        return JSONResponse({"error": "orchestrator not started"}, status_code=400)
    forced = orch.force_schedule(days)
    return {"forced": forced}

@app.post("/admin/concurrency")
async def admin_conc(payload: dict):
    n = int(payload.get("n", 32))
    if orch is None:
        return JSONResponse({"error": "orchestrator not started"}, status_code=400)
    orch.set_concurrency(n)
    return {"concurrency": n}


orch: Orchestrator | None = None
task = None

@app.post("/start")
async def start(concurrency: int = 32):
    global orch, task
    orch = Orchestrator(CSV_PATH, concurrency=concurrency)
    orch.load()
    task = asyncio.create_task(orch.run())
    return {"status": "started", "concurrency": concurrency}

@app.get("/status")
async def status():
    if orch:
        return orch.status_counts()
    return {"total": 0, "done": 0, "open": 0}

@app.post("/stop")
async def stop():
    global orch, task
    if task:
        task.cancel()
    return {"status": "stopping"}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cli", action="store_true")
    parser.add_argument("--concurrency", type=int, default=16)
    args = parser.parse_args()
    if args.cli:
        o = Orchestrator(CSV_PATH, concurrency=args.concurrency)
        o.load()
        asyncio.run(o.run())
        print(o.status_counts())
    else:
        import uvicorn
        uvicorn.run("app.main:app", host="0.0.0.0", port=8080, reload=True)
