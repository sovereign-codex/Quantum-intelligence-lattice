# QIL Full Stack Kit

This kit bundles everything you need to run the Sovereign Intelligence lattice:
- Orchestrator (with Supabase + Storage + Admin UI)
- Next.js dashboard
- CSV → database ingest tools
- One-click Supabase init script + schema

## Files
- `qil_starter_supabase_admin.zip` — Orchestrator with /admin controls (pause/resume/retry/concurrency), Storage uploads
- `qil_starter_supabase_storage.zip` — Orchestrator with Storage (without admin UI)
- `qil_dashboard_next_plus_charts.zip` — Next.js dashboard (filters, artifacts, heatmaps, charts, Vercel-ready)
- `qil_tools.zip` — VOT upsert tool
- `qil_tools_edges.zip` — Edge upsert tool
- `schema.sql` — Tables & RLS policies (run in Supabase SQL editor)
- `init_supabase.py` — One-click ingest (requires service_role key)
- `.env.example` — Environment template

## Supabase setup (10-minute path)
1) Create a Supabase project.
2) Open **SQL** editor → paste and run the contents of `schema.sql`.
3) Create a **Storage bucket** named `artifacts` (or use `QIL_BUCKET`), set public if you want public artifact links.
4) Fill `.env` values using `.env.example` as a guide:
   - Server-side: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `QIL_BUCKET`, `QIL_PUBLIC_URL` (if bucket public)
   - Client-side (dashboard): `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`

## Ingest your CSV (VOT + edges)
Option A — one-click Python:
```bash
pip install supabase==2.6.0
python init_supabase.py --csv /path/to/QIL_365_VOT_Metrics_Plan.csv --url $SUPABASE_URL --key $SUPABASE_SERVICE_ROLE_KEY
```

Option B — per-tool:
```bash
# VOT metadata
unzip qil_tools.zip -d ./qil_tools && cd qil_tools
pip install supabase==2.6.0
python ingest_vot_from_csv.py --csv /path/to/QIL_365_VOT_Metrics_Plan.csv --url $SUPABASE_URL --key $SUPABASE_SERVICE_ROLE_KEY

# Edges
unzip ../qil_tools_edges.zip -d ../qil_tools_edges && cd ../qil_tools_edges
python ingest_edges_from_csv.py --csv /path/to/QIL_365_VOT_Metrics_Plan.csv --url $SUPABASE_URL --key $SUPABASE_SERVICE_ROLE_KEY
```

## Run the orchestrator (admin version)
```bash
unzip qil_starter_supabase_admin.zip -d ./qil_admin && cd qil_admin
pip install -r requirements.txt
# set env: SUPABASE_URL, SUPABASE_KEY (service_role), QIL_DB_BACKEND=supabase, QIL_BUCKET, QIL_PUBLIC_URL
uvicorn app.main:app --port 8080
# visit http://localhost:8080/admin
# POST /start to begin running VOTs
```

## Deploy the dashboard
```bash
unzip ../qil_dashboard_next_plus_charts.zip -d ./qil_dash && cd ./qil_dash
npm install
npm run dev    # http://localhost:3000
# or deploy to Vercel (add NEXT_PUBLIC_* envs)
```

Happy building.
