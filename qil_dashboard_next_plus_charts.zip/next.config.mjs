export default { reactStrictMode: false };
