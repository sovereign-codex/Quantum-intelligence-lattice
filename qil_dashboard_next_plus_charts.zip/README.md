# QIL Dashboard (Next.js + Supabase)

This is a minimal, read-only dashboard for your Quill lattice.

## Setup
1) Copy `.env.local.example` to `.env.local` and fill:
```
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
```
Ensure Supabase RLS allows **select** on `run` and `metric` for `anon`.

2) Install + run:
```
npm install
npm run dev
# open http://localhost:3000
```

## Notes
- The graph uses Cytoscape with a COSE layout.
- By default, `edges` are empty. Expose a public `edge(src int, dst int)` table if you want DAG links:
  - Add RLS `select` for anon.
  - Then fetch edges in `page.tsx`:
```ts
const { data: edgeData } = await supabase.from('edge').select('src, dst');
setEdges(edgeData || []);
```
- The heatmap shows per-day completion (`ok = true` as green).
- Realtime updates listen to changes on `run` table.


## Optional: VOT table for filters (role/theme)
Create a `vot` table to enrich runs with role and theme info for filtering.

```sql
create table if not exists public.vot (
  day int primary key,
  role text,
  theme text
);
alter table public.vot enable row level security;
create policy "read vot" on public.vot for select using (true);
```

Populate it from your CSV (manually or via a quick script).

## Vercel deploy
1) Push this folder to a Git repo.
2) In Vercel, create a new project from the repo.
3) Add env vars:
```
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
```
4) Deploy.
