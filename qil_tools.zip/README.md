# QIL Tools

## Ingest VOT metadata into Supabase

Prereqs:
- `pip install supabase==2.6.0`

Create table (if not already present):
```sql
create table if not exists public.vot (
  day int primary key,
  role text,
  theme text
);
alter table public.vot enable row level security;
create policy "read vot" on public.vot for select using (true);
```

Run:
```bash
python ingest_vot_from_csv.py --csv /path/to/QIL_365_VOT_Metrics_Plan.csv \
  --url $SUPABASE_URL --key $SUPABASE_SERVICE_ROLE_KEY
```
